---
title: Logo Project

notitle: true

description: |
  This project has a sweet logo!

people:
  - storm
  - grad-b
  - ugrad-c

layout: project
image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Xmencomic-logo.svg/2000px-Xmencomic-logo.svg.png"
last-updated: 2017-04-11
---

Some preliminary text.

## header

Maecenas _scelerisque ut enim non convallis_. Mauris ut nisl vitae mi dictum
mollis. Pellentesque iaculis lacinia nisl viverra laoreet. Integer ac lacus quis
elit varius mollis et ultrices tortor. Aliquam id dolor cursus, sagittis arcu
tincidunt, scelerisque nisi. Morbi scelerisque feugiat mi in faucibus. Maecenas
suscipit aliquet est et efficitur. Nullam sed purus nec nulla placerat ultrices
ac at ipsum. Mauris a imperdiet eros.
