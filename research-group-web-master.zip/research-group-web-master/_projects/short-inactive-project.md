---
title: Short Inactive Project
status: inactive

description: |
  This project is quite brief: it only has a description and an external link.
  It's inactive so it should only appear on the "Research" page.

people:
  - storm
  - grad-e
  - collab-a

layout: project
link: "https://en.wikipedia.org/wiki/X-Men"
---
