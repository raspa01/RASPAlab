---
title: Project with a Longer Title
subtitle: And a subtitle

description: |
  This project has a long title, but no other content.
  Setting the `no-link` property means that there's no link.

people:
  - storm
  - profx
  - grad-b
  - scott
  - wolverine

layout: project
no-link: true
last-updated: 2016-11-11
---
