---
layout: default
title: Code
---
This is an example of an additional page you could add to the site (and its navigation).

If you like this template, find our group's other code here:

 * [uwsampa on GitHub](https://github.com/uwsampa/)
